declare module 'inline-worker:*' {
  const code: string;
  export default code;
}
